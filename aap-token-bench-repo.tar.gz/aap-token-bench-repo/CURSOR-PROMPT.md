# Cursor kickoff prompt

Paste the block below into Cursor with the repo open. It assumes you have
extracted the tarball and run `git init`.

---

I'm building a benchmark that measures the token cost of an AI agent doing
infrastructure work two ways: with shell access, versus by calling job
templates through the MCP server for Red Hat Ansible Automation Platform. The
result goes into a published article, so the methodology has to hold up to a
hostile reader.

**Read SPEC.md in full before writing any code.** It defines what is being
measured and lists design rules that look like they could be simplified away.
They can't. If something I ask for later contradicts SPEC.md, tell me rather
than quietly resolving it.

Current state: `harness/harness.py` and `harness/report.py` were written for an
earlier design where both arms acted on SSH-reachable containers. The task has
since changed to provisioning a real EC2 sandbox. `harness/config.yaml`,
`scripts/verify.sh` and `scripts/cleanup.sh` are already written for the AWS
design. The harness is the part that's out of date.

Work through this in order, and stop after each step so I can review:

**1. Bring Arm A in line with the AWS design.**
Replace the SSH-to-containers executor with a workstation executor. Tools:
`run_command(command)` running locally where the AWS CLI is configured and an
SSH key is present, `read_file(path)`, and `list_ssh_targets()` returning
instances created this session. Return real stdout, stderr and exit code, never
truncated. The verbosity is what's being measured. Arm A must be a fair
control, not a strawman.

**2. Wire in verification and cleanup.**
`verify.sh` runs after both arms and decides success. `cleanup.sh` must run in a
`finally`, never only on the happy path, and the harness needs to reset state
between every episode. A failed run that leaves an EC2 instance running is the
only expensive failure mode in this project.

**3. Confirm Arm B still works against a live MCP server.**
It pulls tool definitions at connect time rather than hardcoding them, and it
must discover the right job template itself. Never pass a template ID through
config.

**4. Check what the MCP job status tool actually returns.**
Write a small script that makes one call and prints the raw result. If it
returns full playbook stdout rather than a summary, tell me immediately, before
we build anything else. That would change what this benchmark is measuring.

**5. Generate the AAP template definitions.**
`aap/README.md` lists 20 template names and has a worked example of a
description written for a model rather than a human. Produce the rest in the
same style as configuration-as-code for
`infra.controller_configuration`. Each needs a description covering what it
does, when to choose it, what it will not do, and what it needs, plus a survey
with typed variables. The 19 templates that aren't `provision-dev-sandbox` have
to be plausible enough that choosing between them is a genuine problem.

**6. Do a dry run.**
One repetition per arm. Check the token accounting is sane, verification
passes, and nothing is left running in AWS afterwards. Then we scale to five.

Ask me before adding dependencies beyond `requirements.txt`, before changing
anything in `prompts:` in config.yaml, and before altering the six success
conditions.
