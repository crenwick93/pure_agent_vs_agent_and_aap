#!/usr/bin/env python3
"""
aap-token-bench

Measures token cost of completing an identical task two ways:

  Arm A (control)     model + primitive tools (run_command, read_file, list_inventory)
  Arm B (treatment)   model + AAP MCP server tools only

Everything else is held constant: same model, same temperature, same task text,
same target estate, same success criteria, same run count.

Usage:
    export ANTHROPIC_API_KEY=...
    export AAP_MCP_URL=https://aap.example.com/mcp
    export AAP_TOKEN=...
    python harness.py --config config.yaml --arm both --hosts 5 --runs 5
"""

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
import uuid
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

import yaml
from anthropic import Anthropic

# MCP client is only imported when Arm B actually runs, so Arm A works without it.


# --------------------------------------------------------------------------
# Accounting
# --------------------------------------------------------------------------

@dataclass
class CallRecord:
    """One round trip to the model."""
    turn: int
    input_tokens: int
    output_tokens: int
    cache_read_tokens: int
    cache_write_tokens: int
    stop_reason: str
    tool_calls: list = field(default_factory=list)
    latency_s: float = 0.0


@dataclass
class RunRecord:
    run_id: str
    arm: str
    hosts: int
    model: str
    started_at: str
    calls: list = field(default_factory=list)
    wall_clock_s: float = 0.0
    turns: int = 0
    tool_calls: int = 0
    verified: bool = False
    verify_detail: dict = field(default_factory=dict)
    error: str = ""
    tool_defs_tokens: int = 0   # fixed overhead of the tool surface itself

    @property
    def input_tokens(self):
        return sum(c.input_tokens for c in self.calls)

    @property
    def output_tokens(self):
        return sum(c.output_tokens for c in self.calls)

    @property
    def cache_read_tokens(self):
        return sum(c.cache_read_tokens for c in self.calls)

    def to_dict(self):
        d = asdict(self)
        d["input_tokens"] = self.input_tokens
        d["output_tokens"] = self.output_tokens
        d["cache_read_tokens"] = self.cache_read_tokens
        return d


# --------------------------------------------------------------------------
# Arm A: primitive tools
# --------------------------------------------------------------------------

ARM_A_TOOLS = [
    {
        "name": "list_inventory",
        "description": (
            "List the hosts in scope for this task. Returns hostname, IP address "
            "and current reachability for each host."
        ),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    {
        "name": "run_command",
        "description": (
            "Run a shell command on a target host over SSH as a user with sudo "
            "rights. Returns stdout, stderr and the exit code."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "host": {"type": "string", "description": "Hostname from list_inventory."},
                "command": {"type": "string", "description": "Shell command to run."},
            },
            "required": ["host", "command"],
        },
    },
    {
        "name": "read_file",
        "description": "Read a file from a target host. Returns the file contents.",
        "input_schema": {
            "type": "object",
            "properties": {
                "host": {"type": "string"},
                "path": {"type": "string"},
            },
            "required": ["host", "path"],
        },
    },
]


class ArmAExecutor:
    """Executes primitive tools against the real estate over SSH."""

    def __init__(self, cfg):
        self.cfg = cfg
        self.hosts = cfg["estate"]["hosts"]
        self.ssh_user = cfg["estate"].get("ssh_user", "root")
        self.ssh_opts = cfg["estate"].get(
            "ssh_opts", "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null"
        )
        self.timeout = cfg["estate"].get("command_timeout_s", 120)

    def tools(self):
        return ARM_A_TOOLS

    def _ssh(self, host, command):
        target = self._resolve(host)
        if target is None:
            return f"error: unknown host '{host}'. Call list_inventory first."
        cmd = f"ssh {self.ssh_opts} {self.ssh_user}@{target} {json.dumps(command)}"
        try:
            p = subprocess.run(
                cmd, shell=True, capture_output=True, text=True, timeout=self.timeout
            )
        except subprocess.TimeoutExpired:
            return f"error: command timed out after {self.timeout}s"
        out = []
        if p.stdout:
            out.append(p.stdout.rstrip())
        if p.stderr:
            out.append(f"[stderr]\n{p.stderr.rstrip()}")
        out.append(f"[exit {p.returncode}]")
        return "\n".join(out)

    def _resolve(self, host):
        for h in self.hosts:
            if h["name"] == host or h["address"] == host:
                return h["address"]
        return None

    def call(self, name, args):
        if name == "list_inventory":
            return json.dumps(
                [{"name": h["name"], "address": h["address"]} for h in self.hosts],
                indent=2,
            )
        if name == "run_command":
            return self._ssh(args["host"], args["command"])
        if name == "read_file":
            return self._ssh(args["host"], f"cat {args['path']}")
        return f"error: unknown tool '{name}'"

    def close(self):
        pass


# --------------------------------------------------------------------------
# Arm B: AAP MCP server
# --------------------------------------------------------------------------

class ArmBExecutor:
    """
    Talks to the real AAP MCP server over streamable HTTP.

    Tool definitions are pulled live from the server rather than hardcoded, so
    the measured tool-definition overhead is whatever your AAP actually exposes.
    That overhead is a real cost of this architecture and must be measured, not
    assumed away.
    """

    def __init__(self, cfg):
        from mcp import ClientSession
        from mcp.client.streamable_http import streamablehttp_client

        self.cfg = cfg
        self.url = os.environ.get("AAP_MCP_URL") or cfg["aap"]["mcp_url"]
        self.token = os.environ.get("AAP_TOKEN") or cfg["aap"].get("token", "")
        self.allowlist = cfg["aap"].get("tool_allowlist") or None
        self._ClientSession = ClientSession
        self._client = streamablehttp_client
        self._loop = asyncio.new_event_loop()
        self._ctx = None
        self._session = None
        self._tools = None
        self._loop.run_until_complete(self._connect())

    async def _connect(self):
        headers = {"Authorization": f"Bearer {self.token}"} if self.token else {}
        self._ctx = self._client(self.url, headers=headers)
        read, write, _ = await self._ctx.__aenter__()
        self._session = self._ClientSession(read, write)
        await self._session.__aenter__()
        await self._session.initialize()
        listed = await self._session.list_tools()
        tools = []
        for t in listed.tools:
            if self.allowlist and t.name not in self.allowlist:
                continue
            tools.append(
                {
                    "name": t.name,
                    "description": t.description or "",
                    "input_schema": t.inputSchema,
                }
            )
        self._tools = tools

    def tools(self):
        return self._tools

    def call(self, name, args):
        return self._loop.run_until_complete(self._call(name, args))

    async def _call(self, name, args):
        try:
            res = await self._session.call_tool(name, args)
        except Exception as e:
            return f"error: {e}"
        parts = []
        for c in res.content:
            parts.append(getattr(c, "text", str(c)))
        return "\n".join(parts) if parts else "(empty result)"

    def close(self):
        try:
            self._loop.run_until_complete(self._session.__aexit__(None, None, None))
            self._loop.run_until_complete(self._ctx.__aexit__(None, None, None))
        except Exception:
            pass
        self._loop.close()


# --------------------------------------------------------------------------
# Agent loop
# --------------------------------------------------------------------------

def count_tool_def_tokens(client, model, tools):
    """
    Fixed input-token cost of the tool surface itself, paid on every single turn.
    Arm B typically loses here and wins everywhere else. Measure it.
    """
    try:
        empty = client.messages.count_tokens(
            model=model, messages=[{"role": "user", "content": "x"}]
        )
        withtools = client.messages.count_tokens(
            model=model, messages=[{"role": "user", "content": "x"}], tools=tools
        )
        return withtools.input_tokens - empty.input_tokens
    except Exception:
        return 0


def run_episode(client, cfg, arm, executor, hosts_n, task_text):
    model = cfg["model"]["name"]
    max_turns = cfg["run"]["max_turns"]
    system = cfg["prompts"]["system"]

    rec = RunRecord(
        run_id=str(uuid.uuid4())[:8],
        arm=arm,
        hosts=hosts_n,
        model=model,
        started_at=datetime.now(timezone.utc).isoformat(),
    )

    tools = executor.tools()
    rec.tool_defs_tokens = count_tool_def_tokens(client, model, tools)

    messages = [{"role": "user", "content": task_text}]
    t_start = time.time()

    for turn in range(1, max_turns + 1):
        t0 = time.time()
        try:
            resp = client.messages.create(
                model=model,
                max_tokens=cfg["model"]["max_tokens"],
                temperature=cfg["model"]["temperature"],
                system=system,
                tools=tools,
                messages=messages,
            )
        except Exception as e:
            rec.error = f"api_error: {e}"
            break
        latency = time.time() - t0

        u = resp.usage
        call = CallRecord(
            turn=turn,
            input_tokens=u.input_tokens,
            output_tokens=u.output_tokens,
            cache_read_tokens=getattr(u, "cache_read_input_tokens", 0) or 0,
            cache_write_tokens=getattr(u, "cache_creation_input_tokens", 0) or 0,
            stop_reason=resp.stop_reason,
            latency_s=round(latency, 2),
        )

        messages.append({"role": "assistant", "content": resp.content})

        if resp.stop_reason != "tool_use":
            rec.calls.append(call)
            rec.turns = turn
            break

        results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            call.tool_calls.append(block.name)
            rec.tool_calls += 1
            out = executor.call(block.name, block.input)
            results.append(
                {
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": str(out),
                }
            )

        rec.calls.append(call)
        rec.turns = turn
        messages.append({"role": "user", "content": results})
    else:
        rec.error = f"hit max_turns ({max_turns}) without finishing"

    rec.wall_clock_s = round(time.time() - t_start, 2)
    return rec


# --------------------------------------------------------------------------
# Verification: identical assertions for both arms
# --------------------------------------------------------------------------

def verify(cfg, hosts):
    """
    Runs the same end-state check regardless of how the state was reached.
    Returns (all_passed, per_host_detail).
    """
    script = cfg["verify"]["script"]
    ssh_user = cfg["estate"].get("ssh_user", "root")
    ssh_opts = cfg["estate"].get("ssh_opts", "-o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null")
    detail = {}
    ok = True
    for h in hosts:
        cmd = f"ssh {ssh_opts} {ssh_user}@{h['address']} bash -s"
        p = subprocess.run(
            cmd, shell=True, input=script, capture_output=True, text=True, timeout=120
        )
        passed = p.returncode == 0
        detail[h["name"]] = {
            "passed": passed,
            "output": p.stdout.strip()[-2000:],
        }
        ok = ok and passed
    return ok, detail


# --------------------------------------------------------------------------
# Orchestration
# --------------------------------------------------------------------------

def reset_estate(cfg, hosts_n):
    script = cfg["estate"].get("reset_script")
    if not script:
        return
    subprocess.run(
        script, shell=True, check=False,
        env={**os.environ, "HOST_COUNT": str(hosts_n)},
    )


def build_executor(arm, cfg):
    return ArmAExecutor(cfg) if arm == "A" else ArmBExecutor(cfg)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--arm", choices=["A", "B", "both"], default="both")
    ap.add_argument("--hosts", type=int, action="append",
                    help="Fleet size. Repeat for a sweep: --hosts 1 --hosts 5 --hosts 20")
    ap.add_argument("--runs", type=int, default=None)
    ap.add_argument("--out", default="results")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    runs = args.runs or cfg["run"]["repetitions"]
    sweep = args.hosts or cfg["run"]["host_counts"]
    arms = ["A", "B"] if args.arm == "both" else [args.arm]

    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY not set")

    client = Anthropic()
    outdir = Path(args.out)
    outdir.mkdir(exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    outfile = outdir / f"run-{stamp}.jsonl"

    total = len(sweep) * len(arms) * runs
    n = 0

    with outfile.open("w") as fh:
        for hosts_n in sweep:
            for arm in arms:
                for i in range(runs):
                    n += 1
                    print(f"[{n}/{total}] arm={arm} hosts={hosts_n} rep={i+1}", flush=True)

                    reset_estate(cfg, hosts_n)
                    active = cfg["estate"]["hosts"][:hosts_n]
                    scoped = dict(cfg)
                    scoped["estate"] = {**cfg["estate"], "hosts": active}

                    task = cfg["prompts"]["task"].format(
                        host_count=hosts_n,
                        host_list=", ".join(h["name"] for h in active),
                    )

                    try:
                        ex = build_executor(arm, scoped)
                    except Exception as e:
                        print(f"  executor failed: {e}", file=sys.stderr)
                        continue

                    try:
                        rec = run_episode(client, scoped, arm, ex, hosts_n, task)
                        rec.verified, rec.verify_detail = verify(scoped, active)
                    finally:
                        ex.close()

                    fh.write(json.dumps(rec.to_dict()) + "\n")
                    fh.flush()
                    print(
                        f"  in={rec.input_tokens} out={rec.output_tokens} "
                        f"turns={rec.turns} tools={rec.tool_calls} "
                        f"wall={rec.wall_clock_s}s verified={rec.verified}",
                        flush=True,
                    )

    print(f"\nwrote {outfile}")
    print("now run: python report.py " + str(outfile))


if __name__ == "__main__":
    main()
