#!/usr/bin/env python3
"""
Aggregate harness output into the numbers and the chart the article needs.

    python report.py results/run-*.jsonl --config config.yaml
"""

import argparse
import json
import statistics as stats
from collections import defaultdict
from pathlib import Path

import yaml


def load(paths):
    rows = []
    for p in paths:
        for line in Path(p).read_text().splitlines():
            if line.strip():
                rows.append(json.loads(line))
    return rows


def summarise(rows, price_in, price_out):
    """Group by (hosts, arm) and report central tendency plus spread."""
    groups = defaultdict(list)
    for r in rows:
        groups[(r["hosts"], r["arm"])].append(r)

    out = []
    for (hosts, arm), rs in sorted(groups.items()):
        ok = [r for r in rs if r["verified"] and not r["error"]]
        def col(k):
            return [r[k] for r in ok] or [0]

        tin, tout = col("input_tokens"), col("output_tokens")
        cost = [
            (i / 1_000_000) * price_in + (o / 1_000_000) * price_out
            for i, o in zip(tin, tout)
        ]
        out.append(
            {
                "hosts": hosts,
                "arm": arm,
                "n": len(rs),
                "n_verified": len(ok),
                "success_rate": round(len(ok) / len(rs), 3) if rs else 0.0,
                "input_median": int(stats.median(tin)),
                "input_min": min(tin),
                "input_max": max(tin),
                "input_cv": round(stats.pstdev(tin) / stats.mean(tin), 3) if len(tin) > 1 and stats.mean(tin) else 0.0,
                "output_median": int(stats.median(tout)),
                "turns_median": stats.median(col("turns")),
                "tool_calls_median": stats.median(col("tool_calls")),
                "wall_median_s": round(stats.median(col("wall_clock_s")), 1),
                "tool_defs_tokens": int(stats.median(col("tool_defs_tokens"))),
                "cost_median_usd": round(stats.median(cost), 4),
            }
        )
    return out


def table(summary):
    hdr = (
        f"{'hosts':>6} {'arm':>4} {'ok/n':>7} {'in(med)':>10} {'in cv':>6} "
        f"{'out':>7} {'turns':>6} {'tools':>6} {'wall_s':>7} {'tooldefs':>9} {'$':>9}"
    )
    print(hdr)
    print("-" * len(hdr))
    for s in summary:
        print(
            f"{s['hosts']:>6} {s['arm']:>4} "
            f"{s['n_verified']}/{s['n']:<5} "
            f"{s['input_median']:>10,} {s['input_cv']:>6} "
            f"{s['output_median']:>7,} {s['turns_median']:>6} "
            f"{s['tool_calls_median']:>6} {s['wall_median_s']:>7} "
            f"{s['tool_defs_tokens']:>9,} {s['cost_median_usd']:>9}"
        )


def deltas(summary):
    by = {(s["hosts"], s["arm"]): s for s in summary}
    hosts = sorted({s["hosts"] for s in summary})
    print("\nArm B relative to Arm A (input tokens, median):")
    for h in hosts:
        a, b = by.get((h, "A")), by.get((h, "B"))
        if not (a and b and a["input_median"]):
            continue
        ratio = b["input_median"] / a["input_median"]
        verdict = "B cheaper" if ratio < 1 else "A cheaper"
        print(f"  {h:>3} hosts: {ratio:.2f}x  ({verdict}, {(1-ratio)*100:+.0f}%)")


def chart(summary, path):
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        print("\nmatplotlib not installed, skipping chart")
        return

    hosts = sorted({s["hosts"] for s in summary})
    fig, ax = plt.subplots(figsize=(8, 5))

    for arm, label, colour in [
        ("A", "Pure agent (primitive tools)", "#cc0000"),
        ("B", "Agent + AAP MCP", "#0066cc"),
    ]:
        pts = [s for s in summary if s["arm"] == arm]
        if not pts:
            continue
        pts.sort(key=lambda s: s["hosts"])
        xs = [p["hosts"] for p in pts]
        med = [p["input_median"] for p in pts]
        lo = [p["input_min"] for p in pts]
        hi = [p["input_max"] for p in pts]
        ax.plot(xs, med, marker="o", label=label, color=colour, linewidth=2)
        ax.fill_between(xs, lo, hi, alpha=0.15, color=colour)

    ax.set_xlabel("Hosts onboarded")
    ax.set_ylabel("Input tokens consumed (median, shaded = min/max)")
    ax.set_title("Token cost of onboarding to baseline, by fleet size")
    ax.legend()
    ax.grid(alpha=0.3)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    print(f"\nchart written to {path}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("results", nargs="+")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--chart", default="fleet-sweep.png")
    args = ap.parse_args()

    cfg = yaml.safe_load(Path(args.config).read_text())
    pin = cfg["pricing"]["input_per_mtok_usd"]
    pout = cfg["pricing"]["output_per_mtok_usd"]

    rows = load(args.results)
    if not rows:
        raise SystemExit("no results found")

    s = summarise(rows, pin, pout)
    table(s)
    deltas(s)
    chart(s, args.chart)

    Path("summary.json").write_text(json.dumps(s, indent=2))
    print("summary.json written")


if __name__ == "__main__":
    main()
