# What has to exist in your controller

Arm B talks only to the AAP MCP server. For the benchmark to mean anything,
the controller needs a realistic catalog, not one template sitting on its own.

## Organization

Create **Developer Self-Service**. Scope the MCP token to it. This matters for
more than tidiness: every template description the token can see is read into
context and paid for on every turn, so RBAC scoping is a cost control as much
as a security one. A token that can see all 400 templates in an estate is
expensive before the agent does anything.

## Templates

20 templates. That number is a scoped developer catalog, not a claim about a
typical estate, and the article should say so.

One of them, `provision-dev-sandbox`, does the real work via `amazon.aws`. The
other 19 are plausible neighbours so the agent faces a genuine selection
problem rather than a lookup:

```
provision-dev-sandbox      extend-sandbox-ttl        teardown-sandbox
refresh-db-from-prod       rotate-dev-credentials    seed-test-data
snapshot-sandbox           restore-sandbox           resize-sandbox
attach-shared-volume       grant-temp-db-access      rebuild-app-config
run-integration-suite      sync-secrets              open-firewall-port
tail-app-logs              restart-app-services      check-sandbox-health
list-team-sandboxes        report-sandbox-spend
```

## Write descriptions for a model, not a person

This is the part most people get wrong. The description and survey are the
agent's entire basis for choosing. "Builds a sandbox VM" tells a model nothing
about when to pick this over `resize-sandbox` or `rebuild-app-config`.

Cover four things: what it does, when to choose it, what it will not do, and
what it needs.

```yaml
name: provision-dev-sandbox
description: >
  Creates a new RHEL 9 EC2 instance for development or testing, installs the
  requested packages, applies the standard SSH hardening baseline, restricts
  inbound access to the requesting team's CIDR, registers it in the CMDB and
  sets an automatic teardown date.

  Choose this when someone needs a sandbox that does not exist yet. Do not use
  it to change an existing sandbox: use resize-sandbox to alter its shape or
  extend-sandbox-ttl to postpone teardown. It does not provision databases with
  production data; use refresh-db-from-prod afterwards for that.
survey:
  - variable: rhel_version
    type: integer
    default: 9
  - variable: memory_gb
    type: multiplechoice
    choices: [4, 8, 16, 32]
  - variable: packages
    type: text
    question: Comma-separated package sets, e.g. postgresql16, nginx
  - variable: team
    type: text
  - variable: ttl_days
    type: integer
    default: 7
```

## Credential

The AWS credential lives in the controller. Arm B never sees it, and that is
the point: Arm A needs AWS keys on the workstation to do the same job.

## Loading these

Use `infra.controller_configuration` and keep them as code, the same way you
would any other controller object. `templates/` holds the definitions.
