# aap-token-bench

Measures the token cost of completing one identical task two ways: an AI agent
with shell access doing the work itself, versus the same agent calling a job
template through the MCP server for Red Hat Ansible Automation Platform.

Both arms provision a real EC2 sandbox that passes the same checks. The only
variable is the tool surface.

## Quick start

```bash
pip install -r requirements.txt

export ANTHROPIC_API_KEY=...
export AAP_MCP_URL=https://aap.example.com/mcp
export AAP_TOKEN=...
export AWS_PROFILE=aap-token-bench

python harness/harness.py --config harness/config.yaml --arm both --runs 5
python harness/report.py results/*.jsonl --config harness/config.yaml
./scripts/cleanup.sh
```

## Read SPEC.md first

`SPEC.md` explains the experimental design and lists the rules that make the
result valid. Several of them look like they could be simplified away. They
cannot. Anyone building on this repo, human or agent, should read it before
touching the harness.

## Cost warning

Every run creates a real EC2 instance. Use a dedicated account with a budget
alarm. `scripts/cleanup.sh` terminates by tag and there is an hourly sweeper.
Check for orphans after any failed run.

## Layout

| Path | What |
|---|---|
| `SPEC.md` | design, rules, pitfalls. Start here. |
| `harness/` | agent loop, token accounting, reporting |
| `scripts/` | verification and AWS cleanup |
| `aap/` | job templates and surveys to load into your controller |
| `widget/` | embeddable interactive for the write-up |
| `article-draft.md` | the write-up, figures marked `[[LIKE_THIS]]` |
